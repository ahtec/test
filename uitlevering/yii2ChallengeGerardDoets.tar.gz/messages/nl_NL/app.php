<?php

return [
'Create Visitor' => 'Voeg bezoeker toe',
'Create' => 'Maak',
'Visitors' => 'Bezoekers',
'Visitor' => 'Bezoeker',
'item' => 'aklacht',
'Save' => 'Bewaar' ,
'Update Visitor: ' => 'Wijzig bezoeker: ',
'Update' => 'Wijzig',
'Delete' => 'Verwijder',
'Language' => 'Taal',
'is now'  => 'is nu',
'click to change language' =>'klik om te taal te wijzigen',
'Name' => 'Naam',
'Address' => 'Adres',
'City' => 'Plaats',
'Complain' => 'Klacht'
];
