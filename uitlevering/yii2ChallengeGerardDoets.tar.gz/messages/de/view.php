<?php

return [
'Create' => 'Maak',
'item' => 'klacht',
'The requested page does not exist.' => 'De opgevraagde pagina bestaat niet.',
'Are you sure you want to delete this item?' => 'Weet je zeker dat je dez weg wilt gooien?',
'Create Visitor' => 'Voeg Besuchersr toe',
'Create' => 'erstallen',
'Visitors' => 'Besuchers',
'Visitor' => 'Besucher',
'item' => 'Artikel',
'Save' => 'sparen' ,
'Update Visitor: ' => 'Actualiseren den Besucher: ',
'Update' => 'aktualiseren',
'Delete' => 'Loschen',
'Naam' => 'Nahme',
'Adres' => 'adresse',
'Plaats' => 'Stat',
'Klacht' => 'Beschwerde',
'Language' => 'Sprache',
'is now' => 'isst jetz',
'click to change language' =>'klicken, um die Sprache zu ändern'
];
];
