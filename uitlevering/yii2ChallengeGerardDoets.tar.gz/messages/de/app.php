<?php

return [
'Create Visitor' => 'Voeg Besuchersr toe',
'Create' => 'erstallen',
'Visitors' => 'Besuchers',
'Visitor' => 'Besucher',
'Bezoekers' => 'Besucher',
'item' => 'Artikel',
'Save' => 'sparen' ,
'Update Visitor: ' => 'Actualiseren den Besucher: ',
'Update' => 'aktualiseren',
'Delete' => 'Loschen',
'Naam' => 'Nahme',
'Name' => 'Nahme',
'Adres' => 'adresse',
'Address' => 'adresse',
'Plaats' => 'Stat',
'City' => 'Stat',
'Klacht' => 'Beschwerde',
'Complain' => 'Beschwerde',
'Language' => 'Sprache',
'is now' => 'isst jetz',
'click to change language' =>'klicken, um die Sprache zu ändern'
];
