<?php

return [
'Update Visitor: ' => 'uWijzig bezoeker: ',
'Update' => 'Wijzig',
'Visitors' => 'uBezoekers',
'item' => 'uklacht'
];
