<?php

return [
'Create Visitor' => 'vVoeg bezoeker toe',
'Create' => 'Maak',
'Visitors' => 'Bezoekers',
'item' => 'klacht',
'The requested page does not exist.' => 'De opgevraagde pagina bestaat niet.',
'Are you sure you want to delete this item?' => 'Weet je zeker dat je dez weg wilt gooien?'
];
