<?php

return [
'Create Visitor' => 'iVoeg bezoeker toe',
'Create' => 'Maak',
'Visitors' => 'Bezoekers',
'item' => 'klacht'
];
