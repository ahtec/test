<?php
// uitgebreid door gerard doets in een poging om het veranderen van taal dynamisch te maken

return [
    'adminEmail' => 'admin@example.com',
    'talen' => [
    'nl' => 'nederlands',
    'en' => 'engels',
    'du' => 'duits'
    ],
];
