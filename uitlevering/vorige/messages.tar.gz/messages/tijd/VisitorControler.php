<?php
// file door gerard doets toegevoegd
return [
'Create Visitor' => 'VCVoeg bezoeker toe',
'Create' => 'vcMaak',
'Visitors' => 'vcBezoekers',
'item' => 'vcklacht',
'The requested page does not exist.' => 'vcDe opgevraagde pagina bestaat niet.'
];
