<?php

return [
'Create Visitor' => 'Voeg bezoeker toe',
'Create' => 'aMaak',
'Visitors' => 'Bezoekers',
'item' => 'aklacht',
'Save' => 'Bewaar' ,
'Update Visitor: ' => 'Wijzig bezoeker: ',
'Update' => 'Wijzig',
'Delete' => 'Verwijder'

];
