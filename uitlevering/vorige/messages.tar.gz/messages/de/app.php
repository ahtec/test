<?php

return [
'Create Visitor' => 'Voeg duitse bezoeker toe',
'Create' => 'erstallen',
'Visitors' => 'Besucher',
'item' => 'Artikel',
'Save' => 'sparen' ,
'Update Visitor: ' => 'Actualiseren den Besucher: ',
'Update' => 'aktualiseren',
'Delete' => 'Loschen',
'Naam' => 'Nahme',
'Adres' => 'adresse',
'Plaats' => 'Stat',
'Klacht' => 'Beschwerde'
];
