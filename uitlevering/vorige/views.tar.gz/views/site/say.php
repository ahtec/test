<?php
use yii\helpers\Html;
?>
<p> dit is de hwello wordld applicatie van gerarad <br></p>

<?= Html::encode($message) ?>
